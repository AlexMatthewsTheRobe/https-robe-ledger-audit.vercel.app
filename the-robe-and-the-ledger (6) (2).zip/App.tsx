
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React, { useState, useEffect, useRef } from 'react';
import { 
  ShieldCheck, BookOpen, Scale, FileText, Send, 
  ExternalLink, Lock, Search, AlertCircle, Gavel, 
  Church, GraduationCap, Loader2, Info, ChevronRight,
  Unlock, Ban, ShoppingCart, Activity, List, Terminal
} from 'lucide-react';
import { analyzeWithPRGR, getBriefingResponse, generateAuditorImage, PRGRResult } from './services/geminiService';
import { CHAPTERS, BOOK_METADATA, Chapter } from './data/bookContent';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'briefing' | 'library' | 'audit'>('briefing');
  const [unlockedChapterId, setUnlockedChapterId] = useState<number | null>(null);
  const [chatHistory, setChatHistory] = useState<{ role: 'user' | 'auditor', text: string }[]>([
    { role: 'auditor', text: "System Audit active. I am the Senior Integrity Auditor. Protocols for 'The Robe and the Ledger' are now unsealed. Review the System Orientation in the sidebar before proceeding." }
  ]);
  const [userInput, setUserInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [auditorImage, setAuditorImage] = useState<string | null>(null);
  const [auditInput, setAuditInput] = useState("");
  const [auditResult, setAuditResult] = useState<PRGRResult | null>(null);
  const [isAuditing, setIsAuditing] = useState(false);

  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const saved = localStorage.getItem('unlockedChapter');
    if (saved) setUnlockedChapterId(parseInt(saved));
    
    const initImage = async () => {
      try {
        const img = await generateAuditorImage();
        setAuditorImage(img);
      } catch (e) { console.error(e); }
    };
    initImage();
  }, []);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatHistory]);

  const unlockChapter = (id: number) => {
    if (unlockedChapterId) return;
    setUnlockedChapterId(id);
    localStorage.setItem('unlockedChapter', id.toString());
    const chapter = CHAPTERS.find(c => c.id === id);
    setChatHistory(prev => [...prev, { 
      role: 'auditor', 
      text: `ACCESS GRANTED: Record #${id} ("${chapter?.title}") is now unsealed. Navigate to the Library tab to review the full evidence file.` 
    }]);
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userInput.trim() || isTyping) return;

    const query = userInput;
    setUserInput("");
    setChatHistory(prev => [...prev, { role: 'user', text: query }]);
    setIsTyping(true);

    try {
      const context = unlockedChapterId ? `Chapter ${unlockedChapterId}: ${CHAPTERS.find(c => c.id === unlockedChapterId)?.title}` : undefined;
      const response = await getBriefingResponse(query, context);
      setChatHistory(prev => [...prev, { role: 'auditor', text: response }]);
    } catch (err) {
      setChatHistory(prev => [...prev, { role: 'auditor', text: "Communication blackout. The institution is shielding its data. Please re-submit your query." }]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleAudit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auditInput.trim() || isAuditing) return;
    setIsAuditing(true);
    try {
      const result = await analyzeWithPRGR(auditInput);
      setAuditResult(result);
    } catch (err) { console.error(err); } finally { setIsAuditing(false); }
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 flex flex-col font-sans selection:bg-red-900/40">
      {/* Navigation */}
      <nav className="border-b border-zinc-800 bg-zinc-950/90 backdrop-blur-xl sticky top-0 z-50 px-6">
        <div className="max-w-7xl mx-auto h-20 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <ShieldCheck className="text-red-700 drop-shadow-[0_0_8px_rgba(185,28,28,0.4)]" size={32} />
            <div className="hidden sm:block">
              <h1 className="text-xl font-black tracking-tight text-white uppercase italic">The Robe and the Ledger</h1>
              <p className="text-[9px] text-zinc-500 font-bold tracking-[0.3em] uppercase">Audit Terminal // {BOOK_METADATA.author}</p>
            </div>
          </div>
          <div className="flex items-center gap-6 sm:gap-10">
            <button onClick={() => setActiveTab('briefing')} className={`text-xs font-black uppercase tracking-widest transition-all ${activeTab === 'briefing' ? 'text-red-500 border-b-2 border-red-500 pb-1' : 'text-zinc-500 hover:text-zinc-200'}`}>Briefing</button>
            <button onClick={() => setActiveTab('library')} className={`text-xs font-black uppercase tracking-widest transition-all ${activeTab === 'library' ? 'text-red-500 border-b-2 border-red-500 pb-1' : 'text-zinc-500 hover:text-zinc-200'}`}>Library</button>
            <button onClick={() => setActiveTab('audit')} className={`text-xs font-black uppercase tracking-widest transition-all ${activeTab === 'audit' ? 'text-red-500 border-b-2 border-red-500 pb-1' : 'text-zinc-500 hover:text-zinc-200'}`}>Audit Tool</button>
            <a 
              href="https://books.by/robes-ledgers" 
              target="_blank" 
              className="hidden lg:flex bg-red-800 text-white px-6 py-3 rounded-lg text-[10px] font-black uppercase tracking-[0.2em] hover:bg-red-700 transition-all items-center gap-2 shadow-xl shadow-red-950/40"
            >
              <ShoppingCart size={14} /> Buy Book
            </a>
          </div>
        </div>
      </nav>

      <main className="flex-1 flex flex-col">
        {activeTab === 'briefing' && (
          <div className="flex-1 flex flex-col lg:flex-row max-w-7xl mx-auto w-full px-6 py-8 gap-10 animate-in fade-in duration-700">
            {/* Sidebar orientation */}
            <div className="lg:w-1/3 space-y-6">
              <div className="aspect-[4/5] bg-zinc-900 rounded-3xl overflow-hidden border border-zinc-800 shadow-2xl relative group">
                {auditorImage ? <img src={auditorImage} className="w-full h-full object-cover grayscale brightness-75 group-hover:brightness-100 transition-all duration-1000" alt="Senior Auditor" /> : <div className="absolute inset-0 flex items-center justify-center bg-zinc-900"><Loader2 className="animate-spin text-red-800" /></div>}
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-zinc-950 via-zinc-950/80 to-transparent p-6 pt-20">
                  <div className="px-2 py-0.5 bg-red-900/30 border border-red-800 rounded text-[8px] font-black text-red-500 uppercase tracking-widest w-fit mb-2">Verified Persona</div>
                  <p className="text-lg text-zinc-100 font-bold uppercase tracking-tight">{BOOK_METADATA.author}</p>
                  <p className="text-[10px] text-zinc-500 mt-1 leading-relaxed italic">{BOOK_METADATA.qualifications}</p>
                </div>
              </div>
              
              <div className="bg-zinc-900/50 p-7 rounded-3xl border border-zinc-800/60 space-y-8 backdrop-blur-sm shadow-xl">
                <div className="space-y-4">
                  <h3 className="text-[10px] font-black text-red-600 uppercase tracking-[0.3em] flex items-center gap-3">
                    <List size={16} /> Protocol 1: The Library
                  </h3>
                  <p className="text-[13px] text-zinc-400 leading-relaxed">
                    Navigate to the <span className="text-zinc-100 font-bold">Library</span> tab to access 85 chapters of core evidence. 
                    <br/><br/>
                    <span className="text-red-500 font-black">Warning:</span> You are permitted <span className="underline">one permanent unlock</span> per session. Once unsealed, the system logs your choice as irreversible.
                  </p>
                </div>
                <div className="border-t border-zinc-800/80 pt-8 space-y-4">
                  <h3 className="text-[10px] font-black text-red-600 uppercase tracking-[0.3em] flex items-center gap-3">
                    <Activity size={16} /> Protocol 2: The Audit
                  </h3>
                  <p className="text-[13px] text-zinc-400 leading-relaxed">
                    Use the <span className="text-zinc-100 font-bold">Audit Tool</span> to dissect institutional responses. Input any "official reason" to reveal the Triad mechanism (Money, Intimacy, or Procedure) used to shield the decision-maker from accountability.
                  </p>
                </div>
              </div>
            </div>

            {/* Chat Interface */}
            <div className="lg:w-2/3 flex flex-col bg-zinc-900/40 rounded-[2.5rem] border border-zinc-800 overflow-hidden shadow-2xl h-[700px] relative backdrop-blur-md">
              <div className="p-5 border-b border-zinc-800 bg-zinc-900/80 flex justify-between items-center text-[10px] font-black uppercase tracking-[0.2em] text-zinc-500">
                <span className="flex items-center gap-2"><Terminal size={12} className="text-red-700" /> Auditor Console</span>
                <span className="flex items-center gap-2 text-red-900/60"><Lock size={10} /> Authorized_Access_Only</span>
              </div>
              <div className="flex-1 overflow-y-auto p-10 space-y-8 custom-scrollbar font-mono text-[14px]">
                {chatHistory.map((msg, i) => (
                  <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[85%] p-6 rounded-3xl leading-relaxed shadow-lg ${msg.role === 'user' ? 'bg-red-950/20 border border-red-900/30 rounded-tr-none text-red-50' : 'bg-zinc-800/80 border border-zinc-700/50 rounded-tl-none text-zinc-200'}`}>
                      <p className="whitespace-pre-wrap">{msg.text}</p>
                    </div>
                  </div>
                ))}
                {isTyping && <div className="flex justify-start"><div className="bg-zinc-800/40 px-6 py-4 rounded-3xl animate-pulse text-[10px] font-black uppercase tracking-[0.2em] text-zinc-600">Retrieving secure records...</div></div>}
                <div ref={chatEndRef} />
              </div>
              <form onSubmit={handleSendMessage} className="p-6 bg-zinc-950/80 border-t border-zinc-800 flex gap-4">
                <input value={userInput} onChange={e => setUserInput(e.target.value)} placeholder="Submit a query to the Integrity Auditor..." className="flex-1 bg-zinc-900 border border-zinc-800 rounded-2xl px-6 py-4 text-sm focus:outline-none focus:ring-1 focus:ring-red-900 transition-all placeholder:text-zinc-700 text-zinc-200" />
                <button type="submit" disabled={isTyping} className="bg-red-800 hover:bg-red-600 text-white p-4 rounded-2xl transition-all shadow-xl shadow-red-950/50 disabled:opacity-20"><Send size={20} /></button>
              </form>
            </div>
          </div>
        )}

        {activeTab === 'library' && (
          <div className="max-w-7xl mx-auto w-full px-6 py-16 animate-in slide-in-from-bottom-12 duration-1000">
            <div className="mb-16 border-b border-zinc-800 pb-12 flex flex-col md:flex-row md:items-end justify-between gap-10">
              <div className="space-y-4">
                <h2 className="text-6xl font-black uppercase tracking-tighter italic text-white drop-shadow-md">The Archive</h2>
                <p className="text-zinc-600 font-black uppercase tracking-[0.4em] text-[10px]">Access Clearance: {unlockedChapterId ? 'PERMANENT FILE UNSEALED' : 'AWAITING AUTHORIZATION (0/1)'}</p>
              </div>
              {unlockedChapterId && (
                <div className="bg-red-900/10 border border-red-800/40 px-8 py-4 rounded-full text-[11px] font-black text-red-600 flex items-center gap-3 uppercase tracking-[0.2em] shadow-inner">
                  <Ban size={16} /> Decision Log Locked
                </div>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-12">
              {CHAPTERS.map(chapter => {
                const isUnlocked = unlockedChapterId === chapter.id;
                const isDisabled = unlockedChapterId !== null && !isUnlocked;
                
                return (
                  <div key={chapter.id} className={`p-12 rounded-[3rem] border transition-all duration-700 relative ${isUnlocked ? 'bg-zinc-900 border-red-900 shadow-[0_30px_60px_-15px_rgba(0,0,0,0.8)] scale-[1.01]' : 'bg-zinc-900/30 border-zinc-800/50 hover:border-zinc-700'} ${isDisabled ? 'opacity-20 grayscale pointer-events-none' : ''}`}>
                    <div className="flex justify-between items-start mb-10">
                      <div className="px-4 py-1.5 bg-zinc-950 border border-zinc-800 rounded-full text-[10px] font-black text-red-700 uppercase tracking-widest shadow-lg">Evidence Record #{chapter.id}</div>
                      <div className="p-3 bg-zinc-950/60 rounded-2xl text-zinc-700 border border-zinc-800/50">
                        {chapter.sector === 'Judicial' && <Gavel size={24} />}
                        {chapter.sector === 'Clerical' && <Church size={24} />}
                        {chapter.sector === 'Academic' && <GraduationCap size={24} />}
                      </div>
                    </div>
                    <h3 className="text-4xl font-black mb-6 leading-[0.9] uppercase tracking-tighter italic text-zinc-100">{chapter.title}</h3>
                    
                    {isUnlocked ? (
                      <div className="mt-10 space-y-10 animate-in fade-in slide-in-from-top-6 duration-700">
                        <div className="p-6 bg-red-950/10 border-l-4 border-red-800 italic text-zinc-400 text-base leading-relaxed font-serif">
                          {chapter.subtitle}
                        </div>
                        <div className="text-xl leading-[1.8] font-serif text-stone-300 drop-shadow-sm indent-10 first-letter:text-5xl first-letter:font-black first-letter:text-red-700 first-letter:float-left first-letter:mr-3 first-letter:mt-1">
                          {chapter.content}
                        </div>
                        <div className="pt-12 border-t border-zinc-800/50 flex justify-between items-center opacity-40">
                          <span className="text-[11px] font-black uppercase tracking-[0.3em] text-zinc-600">System Record Finalized // {BOOK_METADATA.author}</span>
                          <ShieldCheck size={20} className="text-red-900" />
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-8">
                        <p className="text-zinc-600 text-sm italic line-clamp-2 leading-relaxed">{chapter.subtitle}</p>
                        <button onClick={() => unlockChapter(chapter.id)} className="w-full flex items-center justify-center gap-4 bg-zinc-800 hover:bg-red-800 text-white py-6 rounded-3xl text-[12px] font-black uppercase tracking-[0.3em] transition-all group shadow-xl">
                          <Unlock size={18} className="group-hover:rotate-12 transition-transform duration-300" /> Unseal Archive File
                        </button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {activeTab === 'audit' && (
          <div className="max-w-4xl mx-auto w-full px-6 py-16 space-y-16 animate-in slide-in-from-right-12 duration-700">
            <div className="text-center space-y-4">
              <h2 className="text-6xl font-black uppercase italic tracking-tighter text-white">The Audit Station</h2>
              <p className="text-zinc-500 text-base max-w-2xl mx-auto font-medium leading-relaxed italic">The PRGR Tool strips institutional "boilerplate" to reveal the underlying Triad Map mechanism used to hide accountability.</p>
            </div>

            <div className="bg-zinc-900/60 border border-zinc-800/50 rounded-[3rem] p-12 shadow-2xl space-y-12 backdrop-blur-xl">
              <form onSubmit={handleAudit} className="space-y-8">
                <div className="relative group">
                  <textarea 
                    value={auditInput} 
                    onChange={e => setAuditInput(e.target.value)} 
                    placeholder="Enter an official reason for harm, delay, or dismissal... (e.g. 'The matter is under internal review by the governance committee.')" 
                    className="w-full bg-zinc-950/90 border border-zinc-800 rounded-3xl p-10 text-lg h-56 focus:outline-none focus:ring-1 focus:ring-red-900 transition-all resize-none custom-scrollbar font-mono placeholder:text-zinc-800 text-zinc-300"
                  />
                  <div className="absolute top-6 right-8 text-[9px] font-black text-zinc-800 uppercase tracking-[0.3em] group-focus-within:text-red-950 transition-colors">Raw_Boilerplate_Input</div>
                </div>
                <button type="submit" disabled={isAuditing || !auditInput.trim()} className="w-full py-6 bg-red-800 hover:bg-red-700 text-white font-black uppercase tracking-[0.4em] text-xs rounded-3xl transition-all flex items-center justify-center gap-4 shadow-2xl shadow-red-950/60 disabled:opacity-20">
                  {isAuditing ? <Loader2 className="animate-spin" size={24} /> : <Search size={24} />} Run System Integrity Audit
                </button>
              </form>

              {auditResult && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 animate-in zoom-in-95 duration-500 font-mono">
                  <div className="p-8 bg-zinc-950/80 rounded-[2rem] border border-zinc-800 space-y-3">
                    <p className="text-[10px] font-black text-zinc-600 uppercase tracking-[0.2em]">Official Narrative</p>
                    <p className="text-sm text-zinc-400 leading-relaxed italic">{auditResult.officialReason}</p>
                  </div>
                  <div className="p-8 bg-red-900/5 rounded-[2rem] border border-red-900/20 space-y-3 shadow-inner">
                    <p className="text-[10px] font-black text-red-800 uppercase tracking-[0.2em]">Revealed Motive</p>
                    <p className="text-base text-zinc-100 font-bold italic tracking-tight">"{auditResult.underlyingMotive}"</p>
                  </div>
                  <div className="p-8 bg-zinc-950/80 rounded-[2rem] border border-zinc-800 flex flex-col justify-center">
                    <p className="text-[10px] font-black text-zinc-600 uppercase tracking-[0.2em] mb-4">Triad Map Category</p>
                    <p className="text-3xl font-black text-red-700 uppercase italic tracking-tighter drop-shadow-lg">{auditResult.mechanism}</p>
                  </div>
                  <div className="p-8 bg-zinc-950/80 rounded-[2rem] border border-zinc-800 flex flex-col justify-center">
                    <p className="text-[10px] font-black text-zinc-600 uppercase tracking-[0.2em] mb-4">Downstream Erosion</p>
                    <div className="flex items-center gap-5">
                       <div className="flex-1 h-2 bg-zinc-900 rounded-full overflow-hidden border border-zinc-800">
                          <div className="h-full bg-red-800 shadow-[0_0_10px_rgba(153,27,27,0.8)]" style={{ width: auditResult.erosionLevel }} />
                       </div>
                       <span className="text-lg font-black text-red-500">{auditResult.erosionLevel}</span>
                    </div>
                  </div>
                  <div className="md:col-span-2 p-10 bg-zinc-800/30 rounded-[2.5rem] border border-zinc-700/50 space-y-6 backdrop-blur-sm">
                    <div className="flex justify-between items-center border-b border-zinc-700/50 pb-6">
                      <span className="text-[11px] font-black uppercase tracking-[0.3em] text-zinc-500">Proposed Personal Reason-Giving (PRGR)</span>
                      <span className="text-[9px] font-black text-white bg-red-900/80 px-4 py-1.5 rounded-full tracking-widest">SIGNATORY: {auditResult.decisionAuthor}</span>
                    </div>
                    <p className="text-lg leading-relaxed text-stone-200 font-serif italic drop-shadow-sm">{auditResult.remedyTrigger}</p>
                    <div className="flex justify-between items-center opacity-40">
                      <p className="text-[10px] text-zinc-600 uppercase tracking-widest font-black">Audit Ref: PRGR-{Math.floor(Math.random()*9000)+1000}-X</p>
                      <ShieldCheck size={18} />
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </main>

      <footer className="h-28 border-t border-zinc-900 bg-zinc-950 px-10 flex items-center">
        <div className="max-w-7xl mx-auto w-full flex flex-col md:flex-row justify-between items-center gap-6 text-[10px] font-black uppercase tracking-[0.4em] text-zinc-800">
          <div className="flex items-center gap-6">
            <span className="text-zinc-600">{BOOK_METADATA.author}</span>
            <span className="w-1 h-1 bg-zinc-800 rounded-full" />
            <span className="text-zinc-700 lowercase tracking-normal italic opacity-60 font-serif text-[11px] font-medium">{BOOK_METADATA.qualifications}</span>
          </div>
          <div className="flex gap-12 items-center">
            <a href="https://books.by/robes-ledgers" target="_blank" className="text-red-900 hover:text-red-600 transition-colors">Purchase Full Copy</a>
            <a href="https://www.robeledger.com" target="_blank" className="text-zinc-400 hover:text-red-800 transition-all font-black border-2 border-zinc-900 px-6 py-2.5 rounded-xl hover:border-red-950">WWW.ROBELEDGER.COM</a>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
