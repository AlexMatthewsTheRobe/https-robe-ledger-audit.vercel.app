
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import { GoogleGenAI, Type } from "@google/genai";
import { BOOK_METADATA } from "../data/bookContent";

const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

export interface PRGRResult {
  officialReason: string;
  underlyingMotive: string;
  mechanism: string;
  erosionLevel: string;
  foreseeableHarm: string;
  remedyTrigger: string;
  decisionAuthor: string;
}

export const analyzeWithPRGR = async (scenario: string): Promise<PRGRResult> => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `Analyze this scenario using the 'Triad Map' from Alex Matthews' book 'The Robe and the Ledger'.
    
    Triad Logic:
    - Money: Access, Silence, Speed, Immunity
    - Intimacy: Confession, Dependence, Shame, Loyalty
    - Procedure: Delay, Disappearance, Deference, Distance
    
    Scenario: "${scenario}"
    
    Create a formal Personal Reason-Giving Record (PRGR) as described in the book.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          officialReason: { type: Type.STRING, description: "The bureaucratic boilerplate." },
          underlyingMotive: { type: Type.STRING, description: "The actual power-preserving motive." },
          mechanism: { type: Type.STRING, description: "Which part of the Triad (Money, Intimacy, Procedure) is at play." },
          erosionLevel: { type: Type.STRING, description: "Percentage of trust destroyed." },
          foreseeableHarm: { type: Type.STRING, description: "Specific harm to the individual downstream." },
          remedyTrigger: { type: Type.STRING, description: "A pre-committed action that activates if the author is wrong." },
          decisionAuthor: { type: Type.STRING, description: "The specific role that must own this decision." }
        },
        required: ["officialReason", "underlyingMotive", "mechanism", "erosionLevel", "foreseeableHarm", "remedyTrigger", "decisionAuthor"]
      }
    }
  });

  return JSON.parse(response.text || "{}");
};

export const getBriefingResponse = async (userQuery: string, currentContext?: string): Promise<string> => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: userQuery,
    config: {
      systemInstruction: `You are the "Senior Integrity Auditor", presenting Alex Matthews' book "The Robe and the Ledger". 
      The book's thesis: "Justice is not blind. Sometimes, it simply peeks the other way."
      Current Reading Context: ${currentContext || "General Briefing"}
      
      Your goal is to help the user understand the 'machinery of concealment' in judicial, clerical, and academic sectors. 
      Use terms like 'Boilerplate is a kind of lying', 'Costumes of authority', and 'The Author has to exist'.
      Speak with gravitas, professional cynicism, and a focus on structural accountability.
      If the user asks a question, use the book's logic (Money/Intimacy/Procedure) to answer.`
    }
  });
  return response.text || "Connection to the system lost.";
};

export const generateAuditorImage = async (): Promise<string> => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: 'A cinematic, high-detail portrait of a middle-aged man, an authoritative auditor in modern legal robes with a crimson neckpiece, looking directly at the camera with a stern and intelligent expression. Dark, bureaucratic background with dramatic lighting.',
    config: { imageConfig: { aspectRatio: "1:1" } }
  });

  for (const part of response.candidates?.[0]?.content?.parts || []) {
    if (part.inlineData) return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
  }
  return "";
};
