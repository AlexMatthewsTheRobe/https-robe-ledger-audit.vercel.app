
export interface Chapter {
  id: number;
  title: string;
  subtitle?: string;
  content: string;
  sector: 'Judicial' | 'Clerical' | 'Academic' | 'Cross-Sector';
}

export const BOOK_METADATA = {
  author: "Alex Matthews",
  qualifications: "TLM-LLM, BSc, BA - Former Solicitor/Barrister, Tax Lawyer, Mediator, Advisor, Arbitrator",
  core_thesis: "In a world of robes and jabots, truth is the one thing nobody can afford.",
  solution: "Personal Reason-Giving Record (PRGR)",
  triad_map: {
    money: ["Access", "Silence", "Speed", "Immunity"],
    intimacy: ["Confession", "Dependence", "Shame", "Loyalty"],
    procedure: ["Delay", "Disappearance", "Deference", "Distance"]
  }
};

export const CHAPTERS: Chapter[] = [
  {
    id: 1,
    title: "The Invisible Hand, The Enkolpion, and The Mantle",
    subtitle: "Three thresholds. Three doors. Three versions of authority putting itself on.",
    sector: "Cross-Sector",
    content: `Bellini’s robe did what robes are designed to do: it made the person inside it less personal. It made his movements appear ordained rather than chosen. Reed’s mantle was not fabric in the lab; it was reputation. It was the ceremonial stole he wore on conference stages, the polished language of innovation, the unspoken privilege that comes with being the one everyone calls a "leader in the field." He loved control the way certain men love silence: not for peace, but for ownership. None of them woke up that morning thinking, Today I will cross the line. They woke up thinking, Today I must keep the institution stable. Stewards who confuse survival with virtue cross the line everywhere, not monsters.`
  },
  {
    id: 2,
    title: "The Prosecutor's Shadow",
    subtitle: "Subtle manipulation can devastate trust even when it leaves no overt trace.",
    sector: "Judicial",
    content: `Prosecutor Alain Dupont was the meticulous kind—the man who learned early that institutions reward those who never force the room to admit it is being forced. He kept a small black notebook in the inside pocket of his robe. It contained lists. Names, dates, the stray phrase a junior had used that revealed insecurity. "Over-apologizes." "Needs to be chosen." "Will fold if corrected in public." It looked like professional diligence. It was professional diligence, just applied to humans the way one applies it to evidence. He believed the notebook made him better at his job. In reality, it simply made the job better at consuming him.`
  },
  {
    id: 6,
    title: "The Gabbai's Kittel",
    subtitle: "White cloth does not make clean hands.",
    sector: "Clerical",
    content: `Gavriel Stein, the gabbai, wore his own kittel beneath a dark jacket, as though he wanted the purity close but not too visible. He liked things orderly—who sat where, who received honors, who got which prayer. Order was his liturgy, his private form of devotion. The tzedakah fund was the synagogue's quiet heart. But there was also discretion, and discretion is a door that can swing either way. Each time he borrowed, he left a trail of small notes to himself and moved money between categories the way a skilled hand moves cards: gently, without noise. In the ledger he wrote the words that tranquilize conscience—reimbursement pending, bridge, timing issue. He wasn't stealing, he told himself; he was merely managing the rhythm of providence.`
  },
  {
    id: 21,
    title: "The Dean's Compromised Agenda",
    subtitle: "Ceremony can be impeccable while the structure beneath corrodes.",
    sector: "Academic",
    content: `Dean Margaret Whitmore spoke about opportunity, innovation, and "ethical leadership" with the polished cadence of someone who knows which words reassure. Whitmore told herself the money would serve the institution. She told herself she was protecting jobs, research, and student futures. She told herself she was doing what leadership requires: making unpleasant compromises so others don’t have to. Once you learn which valves control the flow—funding, prestige, access—you treat people like variables. The moral cost, she decided, was an administrative overhead she alone would bear. But moral costs, like fiscal ones, eventually demand an audit.`
  },
  {
    id: 28,
    title: "The Wrongly Condemned",
    subtitle: "Systems don’t run on repentance. They run on risk management.",
    sector: "Judicial",
    content: `In court, the accused learned something most people never learn: "truth" is not a substance. It's a performance standard. If you hesitate, you look guilty. If you speak in loops, you look guilty. If you can’t explain yourself in the polished shape the room expects, the room assumes you’re hiding something. The system says it runs on facts. In reality, it runs on human susceptibility. And the most dangerous susceptibility of all lies in the desire to believe that the institution cannot be wrong. To admit error is to invite the collapse of the costume, and the system prefers an innocent man in a cell to a naked judge.`
  },
  {
    id: 51,
    title: "The House on the Hill",
    subtitle: "Long-term systemic failure.",
    sector: "Clerical",
    content: `Correctness was not a destination—it was a moving target designed to keep her mind bent forward, always reaching, always apologizing. The Mother sat behind a desk that held a ledger. Thick, dark, authoritative. The book lay open like scripture. A pen rested beside it, angled precisely, as if even ink must submit. "Here," the Mother said, "we learn to die to ourselves." Pain can become a currency if belonging is rationed. A kind word after humiliation can feel like mercy. This is how systems outlive outrage: they convert harm into devotion, until the prisoner believes the cage is the only place they are truly understood.`
  }
];
